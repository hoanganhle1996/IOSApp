//
//  ViewController.swift
//  I am Rich
//
//  Created by AnhLeHoang on 07/08/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

